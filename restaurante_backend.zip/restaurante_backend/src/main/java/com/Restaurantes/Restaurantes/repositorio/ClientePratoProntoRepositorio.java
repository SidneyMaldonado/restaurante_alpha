package com.Restaurantes.Restaurantes.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Restaurantes.Restaurantes.entity.ClientePratoPronto;

public interface ClientePratoProntoRepositorio extends JpaRepository<ClientePratoPronto, Integer>{

}
