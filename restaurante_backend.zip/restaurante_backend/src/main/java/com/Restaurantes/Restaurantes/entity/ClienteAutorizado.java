package com.Restaurantes.Restaurantes.entity;

import java.util.List;

public class ClienteAutorizado {

	private Boolean autorizado;

	public Boolean getAutorizado() {
		return autorizado;
	}

	public void setAutorizado(Boolean autorizado) {
		this.autorizado = autorizado;
	}

	
}
