package com.Restaurantes.Restaurantes.entity;

public class ClienteLogin {


	private Integer codCliente;
	

	private String senha;
	
	
	public Integer getCodCliente() {
		return codCliente;
	}

	public void setCodCliente(Integer codCliente) {
		this.codCliente = codCliente;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}


}
