package com.Restaurantes.Restaurantes.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Restaurantes.Restaurantes.entity.Pagamento;

public interface PagamentoRepositorio extends JpaRepository<Pagamento, Integer>{

}
